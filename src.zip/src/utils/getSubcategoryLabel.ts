// Centraliza la obtención del literal de subcategoría para HomePage y MaterialCategorySelect
export { getSubcategoryLabel } from './subcategoryLabel'; 
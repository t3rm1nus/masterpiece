// Tipos de props de componentes React
// Ejemplo:
// export interface ButtonProps {
//   label: string;
//   onClick?: () => void;
// } 
// Tipos de APIs y respuestas
// Aquí puedes definir interfaces y tipos para las respuestas de tus APIs 
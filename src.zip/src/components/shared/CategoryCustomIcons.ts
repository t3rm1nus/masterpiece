// =============================================
// CategoryCustomIcons: Colección de iconos personalizados por categoría
// Colección de iconos personalizados por categoría. Optimizado para visualización y consistencia UI.
// =============================================

import OndemandVideoIcon from '@mui/icons-material/OndemandVideo';
import LiveTvIcon from '@mui/icons-material/LiveTv';

export { OndemandVideoIcon, LiveTvIcon }; 
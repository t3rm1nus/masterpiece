// =============================================
// ItemDetail: Componente legacy de detalle de ítem
// Componente legacy. No usar en nuevas implementaciones, migrar a UnifiedItemDetail.
// =============================================

// Este componente ha sido migrado a TypeScript pero está marcado como legacy.
// Para nuevas implementaciones, usar UnifiedItemDetail.tsx en su lugar. 